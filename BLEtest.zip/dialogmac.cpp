#include "dialogmac.h"
#include "ui_dialogmac.h"

#include <QStringList>
extern QStringList myList;
extern int shutdown_Dialog;

DialogMac::DialogMac(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DialogMac)
{
    ui->setupUi(this);
//    Interface = new BLEInterface(this);
//    Interface->scanDevices();
//    connect(Interface, &BLEInterface::devicesNamesChanged,
//            [this] (QStringList devices){
//        ui->listWidget->clear();
//        ui->listWidget->addItems(devices);
//    });
    myTimer = new QTimer(this);
    connect(myTimer, SIGNAL(timeout()), this, SLOT(clearLabel()));
    myTimer2 = new QTimer(this);
    connect(myTimer2, SIGNAL(timeout()), this, SLOT(changemaclist()));
    myTimer2->start(5010);
}

DialogMac::~DialogMac()
{
    delete ui;
}

void DialogMac::changemaclist()
{
    if(cal>10)
    {
        myTimer2->stop();
    }
    else
    {
        ui->listWidget->clear();
        ui->listWidget->addItems(myList);
        cal++;
    }
}

void DialogMac::Delay_MSec(unsigned int msec)
{
    QEventLoop loop;//定义一个新的事件循环
    QTimer::singleShot(msec, &loop, SLOT(quit()));//创建单次定时器，槽函数为事件循环的退出函数
    loop.exec();//事件循环开始执行，程序会卡在这里，直到定时时间到，本循环被退出
}

void DialogMac::clearLabel()
{
    ui->labelState->clear();
    if(shutdown_Dialog==1)
    {
        myTimer->stop();
        ui->btnCancle->click();
    }
    else
    {
        ui->labelState->setText(tr("连接超时"));
        Delay_MSec(5000);
        ui->labelState->clear();
        myTimer->stop();
    }
}

void DialogMac::on_btnConnect_clicked()
{
    myTimer->start(9000);
    ui->labelState->setText(tr("蓝牙连接中"));
    if (ui->listWidget->selectedItems().isEmpty())
    {
        emit setDevice(0);
    }
    else
    {
        QListWidgetItem* current_item = ui->listWidget->currentItem();
        emit setDevice(ui->listWidget->row(current_item));
    }
}

