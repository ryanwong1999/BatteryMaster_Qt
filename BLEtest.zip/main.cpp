#include "batterywidget.h"

#include <QApplication>
#include <QTranslator>

QString readSetting();

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    BatteryWidget w;
    w.setWindowIcon(QIcon(":/image/batteryTopico.ico"));
    w.show();
    return a.exec();
}
