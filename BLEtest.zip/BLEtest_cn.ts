<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>BatteryWidget</name>
    <message>
        <location filename="batterywidget.ui" line="26"/>
        <source>BM 系列 电池检测-充电-放电-维护仪客户端软件 (V1.0 3.21 )</source>
        <oldsource>BM 系列 电池检测-充电-放电-维护仪客户端软件 (V1.1)</oldsource>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="77"/>
        <source>℃</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="99"/>
        <location filename="batterywidget.ui" line="578"/>
        <location filename="batterywidget.ui" line="625"/>
        <source>V</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="145"/>
        <source>电池类型</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="218"/>
        <source>Ah</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="240"/>
        <source>充电电压</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="313"/>
        <source>mΩ</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="335"/>
        <source>充电电流</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="360"/>
        <source>电池参数设置</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="385"/>
        <source>电池容量</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="410"/>
        <source>放电截至</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="435"/>
        <location filename="batterywidget.ui" line="556"/>
        <source>A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="481"/>
        <source>电池电压</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="506"/>
        <source>放电电流</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="531"/>
        <source>温度截至</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="600"/>
        <source>电池内阻</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="671"/>
        <location filename="batterywidget.cpp" line="1115"/>
        <location filename="batterywidget.cpp" line="1438"/>
        <source>电池</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="694"/>
        <source>保存</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="909"/>
        <source>锂离子</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="914"/>
        <source>铁锂</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="919"/>
        <source>铅酸</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="924"/>
        <source>镍氢</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="1036"/>
        <source>--V --Ah --电池 --串级联</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="1839"/>
        <source>设置状态</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="2005"/>
        <source>1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="2010"/>
        <source>2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="1073"/>
        <source>设备详细信息</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="969"/>
        <source>校对</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="1098"/>
        <source>设备型号</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="1123"/>
        <source>充放电压</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="1148"/>
        <source>充放电流</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="1173"/>
        <source>充电功率</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="1198"/>
        <source>放电功率</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="1223"/>
        <source>蓝牙功能</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="1248"/>
        <source>级联功能</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="1273"/>
        <source>硬件版本</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="1298"/>
        <source>固件版本</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="1323"/>
        <location filename="batterywidget.ui" line="1345"/>
        <location filename="batterywidget.ui" line="1367"/>
        <location filename="batterywidget.ui" line="1389"/>
        <source>--</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="1411"/>
        <source>主机模式</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="1433"/>
        <source>R1.0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="1662"/>
        <source>V1.0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="1684"/>
        <source>有</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="1727"/>
        <source>暂停恢复</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="1749"/>
        <source>单次充电</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="1771"/>
        <source>自动维护</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="1793"/>
        <source>单次放电</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="1816"/>
        <source>快速检测</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="1864"/>
        <source>运行时间</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="2175"/>
        <location filename="batterywidget.ui" line="2408"/>
        <source>蓝牙连接</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="1911"/>
        <source>市电状态</source>
        <oldsource>市电</oldsource>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="1958"/>
        <source>电池状态</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="2015"/>
        <source>序号</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="2020"/>
        <source>电压(V)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="2025"/>
        <source>电流(A)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="2030"/>
        <source>内阻(mΩ)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="2035"/>
        <source>SOC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="2040"/>
        <source>SOH</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="2045"/>
        <source>充入容量</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="2050"/>
        <source>触点温度</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="2152"/>
        <source>中文</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="2202"/>
        <source>清空</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="2228"/>
        <source>设备</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="2274"/>
        <location filename="batterywidget.cpp" line="553"/>
        <source>连接</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="2293"/>
        <source>Hex</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="2306"/>
        <source>ASCII</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="2325"/>
        <source>服务</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="2348"/>
        <source>发送</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="2385"/>
        <source>返回主页</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.cpp" line="535"/>
        <source>最大 5.0V</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.cpp" line="536"/>
        <source>最大 30.0A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.cpp" line="537"/>
        <source>最大 150W</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.cpp" line="538"/>
        <location filename="batterywidget.cpp" line="544"/>
        <source>最大 90W</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.cpp" line="541"/>
        <source>最大 32.0V</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.cpp" line="542"/>
        <source>最大 8.0A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.cpp" line="543"/>
        <source>最大 200W</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.cpp" line="548"/>
        <source>未接入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.cpp" line="549"/>
        <source>接入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.cpp" line="744"/>
        <source>待机</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.cpp" line="745"/>
        <source>充电中</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.cpp" line="746"/>
        <source>暂停充电</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.cpp" line="747"/>
        <source>充电完成</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.cpp" line="748"/>
        <source>空电充满</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.cpp" line="749"/>
        <source>非空起充</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.cpp" line="750"/>
        <source>放电中</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.cpp" line="751"/>
        <source>暂停放电</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.cpp" line="752"/>
        <source>放电完成</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.cpp" line="753"/>
        <source>满电放空</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.cpp" line="754"/>
        <source>半电放空</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.cpp" line="755"/>
        <source>检测中</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.cpp" line="756"/>
        <source>检测完成</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.cpp" line="757"/>
        <source>维护充电</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.cpp" line="758"/>
        <source>维护放电</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.cpp" line="759"/>
        <source>暂停维护</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.cpp" line="760"/>
        <source>维护完成</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.cpp" line="761"/>
        <source>短路</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.cpp" line="762"/>
        <source>过压</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.cpp" line="763"/>
        <source>过流</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.cpp" line="764"/>
        <source>过温</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.cpp" line="765"/>
        <source>风扇异常</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.cpp" line="766"/>
        <source>请接市电</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.cpp" line="767"/>
        <source>电池异常</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="1889"/>
        <location filename="batterywidget.cpp" line="552"/>
        <source>未连接</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.cpp" line="1115"/>
        <location filename="batterywidget.cpp" line="1438"/>
        <source>串级联</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DialogMac</name>
    <message>
        <location filename="dialogmac.ui" line="14"/>
        <source>选择设备</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dialogmac.ui" line="36"/>
        <source>确认</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dialogmac.ui" line="49"/>
        <source>取消</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dialogmac.cpp" line="54"/>
        <source>连接超时</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dialogmac.cpp" line="63"/>
        <source>蓝牙连接中</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
