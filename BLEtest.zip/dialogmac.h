#ifndef DIALOGMAC_H
#define DIALOGMAC_H

#include <QDialog>
#include "bleinterface.h"

namespace Ui {
class DialogMac;
}

class DialogMac : public QDialog
{
    Q_OBJECT

public:
    explicit DialogMac(QWidget *parent = nullptr);
    ~DialogMac();

private slots:
    void on_btnConnect_clicked();
    void clearLabel();
    void changemaclist();
    void Delay_MSec(unsigned int);

signals:
    void setDevice(int);
private:
    BLEInterface *Interface;
    Ui::DialogMac *ui;
    QTimer *myTimer;
    QTimer *myTimer2;
    int cal=0;
};

#endif // DIALOGMAC_H
