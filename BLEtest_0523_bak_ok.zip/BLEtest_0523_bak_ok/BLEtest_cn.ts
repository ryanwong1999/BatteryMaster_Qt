<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>BatteryWidget</name>
    <message>
        <location filename="batterywidget.ui" line="26"/>
        <source>BM 系列 电池检测-充电-放电-维护仪客户端软件 (V1.4 5.23)</source>
        <oldsource>BM 系列 电池检测-充电-放电-维护仪客户端软件 (V1.2 3.29 )</oldsource>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="82"/>
        <source>℃</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="104"/>
        <location filename="batterywidget.ui" line="583"/>
        <location filename="batterywidget.ui" line="630"/>
        <source>V</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="150"/>
        <source>电池类型</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="223"/>
        <source>Ah</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="245"/>
        <source>充电电压</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="318"/>
        <source>mΩ</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="340"/>
        <source>充电电流</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="365"/>
        <source>电池参数设置</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="390"/>
        <source>电池容量</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="415"/>
        <source>放电截至</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="440"/>
        <location filename="batterywidget.ui" line="561"/>
        <location filename="batterywidget.cpp" line="1178"/>
        <location filename="batterywidget.cpp" line="1190"/>
        <source>A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="486"/>
        <source>电池电压</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="511"/>
        <source>放电电流</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="536"/>
        <location filename="batterywidget.cpp" line="1159"/>
        <location filename="batterywidget.cpp" line="1168"/>
        <source>温度截至</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="605"/>
        <source>电池内阻</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="676"/>
        <location filename="batterywidget.cpp" line="1974"/>
        <location filename="batterywidget.cpp" line="2304"/>
        <source>电池</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="699"/>
        <source>保存</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="914"/>
        <source>锂离子</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="919"/>
        <source>铁锂</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="924"/>
        <source>铅酸</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="929"/>
        <source>镍氢</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="1041"/>
        <source>--V --Ah --电池 --串级联</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="2010"/>
        <source>1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="1078"/>
        <source>设备详细信息</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="974"/>
        <source>校对</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="1103"/>
        <source>设备型号</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="1128"/>
        <source>充放电压</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="1153"/>
        <source>充放电流</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="1178"/>
        <source>充电功率</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="1203"/>
        <source>放电功率</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="1228"/>
        <source>蓝牙功能</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="1253"/>
        <source>级联功能</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="1278"/>
        <source>硬件版本</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="1303"/>
        <source>固件版本</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="1328"/>
        <location filename="batterywidget.ui" line="1350"/>
        <location filename="batterywidget.ui" line="1372"/>
        <location filename="batterywidget.ui" line="1394"/>
        <source>--</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="1416"/>
        <source>主机模式</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="1438"/>
        <source>R1.0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="1667"/>
        <source>V1.0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="1689"/>
        <source>有</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="1732"/>
        <source>暂停恢复</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="1754"/>
        <source>单次充电</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="1776"/>
        <source>自动维护</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="1798"/>
        <source>单次放电</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="1821"/>
        <source>快速检测</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="1844"/>
        <source>运行状态</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="1869"/>
        <source>运行时间</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="2183"/>
        <source>连接设备</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="2217"/>
        <source>蓝牙模式</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="2233"/>
        <source>485 模式</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="2486"/>
        <source>蓝牙连接</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="1916"/>
        <source>市电状态</source>
        <oldsource>市电</oldsource>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="1963"/>
        <source>电池状态</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="2015"/>
        <source>序号</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="2020"/>
        <source>电压(V)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="2025"/>
        <source>电流(A)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="2030"/>
        <source>内阻(mΩ)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="2035"/>
        <source>SOC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="2040"/>
        <source>SOH</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="2045"/>
        <source>充入容量</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="2050"/>
        <source>触点温度</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="2160"/>
        <source>中文</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="2280"/>
        <source>清空</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="2306"/>
        <source>设备</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="2352"/>
        <location filename="batterywidget.cpp" line="741"/>
        <location filename="batterywidget.cpp" line="1555"/>
        <source>连接</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="2371"/>
        <source>Hex</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="2384"/>
        <source>ASCII</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="2403"/>
        <source>服务</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="2426"/>
        <source>发送</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="2463"/>
        <source>返回主页</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.cpp" line="296"/>
        <location filename="batterywidget.cpp" line="1653"/>
        <location filename="batterywidget.cpp" line="1848"/>
        <source>检测</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.cpp" line="297"/>
        <location filename="batterywidget.cpp" line="1701"/>
        <location filename="batterywidget.cpp" line="1849"/>
        <source>充电</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.cpp" line="298"/>
        <location filename="batterywidget.cpp" line="1744"/>
        <location filename="batterywidget.cpp" line="1850"/>
        <source>放电</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.cpp" line="299"/>
        <location filename="batterywidget.cpp" line="1787"/>
        <location filename="batterywidget.cpp" line="1851"/>
        <source>维护</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.cpp" line="306"/>
        <location filename="batterywidget.cpp" line="1860"/>
        <source>暂停</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.cpp" line="723"/>
        <location filename="batterywidget.cpp" line="1155"/>
        <location filename="batterywidget.cpp" line="1173"/>
        <source>最大 5.0V</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.cpp" line="724"/>
        <location filename="batterywidget.cpp" line="1156"/>
        <source>最大 30.0A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.cpp" line="725"/>
        <location filename="batterywidget.cpp" line="1157"/>
        <source>最大 150W</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.cpp" line="726"/>
        <location filename="batterywidget.cpp" line="732"/>
        <location filename="batterywidget.cpp" line="1158"/>
        <location filename="batterywidget.cpp" line="1167"/>
        <location filename="batterywidget.cpp" line="1176"/>
        <location filename="batterywidget.cpp" line="1188"/>
        <source>最大 90W</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.cpp" line="729"/>
        <location filename="batterywidget.cpp" line="1164"/>
        <source>最大 32.0V</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.cpp" line="730"/>
        <location filename="batterywidget.cpp" line="1165"/>
        <location filename="batterywidget.cpp" line="1174"/>
        <location filename="batterywidget.cpp" line="1186"/>
        <source>最大 8.0A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.cpp" line="731"/>
        <location filename="batterywidget.cpp" line="1166"/>
        <source>最大 200W</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.cpp" line="736"/>
        <location filename="batterywidget.cpp" line="1548"/>
        <source>未接入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.cpp" line="737"/>
        <location filename="batterywidget.cpp" line="1549"/>
        <source>接入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.cpp" line="930"/>
        <location filename="batterywidget.cpp" line="1561"/>
        <source>待机</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.cpp" line="931"/>
        <location filename="batterywidget.cpp" line="1562"/>
        <source>充电中</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.cpp" line="932"/>
        <location filename="batterywidget.cpp" line="1563"/>
        <source>暂停充电</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.cpp" line="933"/>
        <location filename="batterywidget.cpp" line="1564"/>
        <source>充电完成</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.cpp" line="934"/>
        <location filename="batterywidget.cpp" line="1565"/>
        <source>空电充满</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.cpp" line="935"/>
        <location filename="batterywidget.cpp" line="1566"/>
        <source>非空起充</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.cpp" line="936"/>
        <location filename="batterywidget.cpp" line="1567"/>
        <source>放电中</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.cpp" line="937"/>
        <location filename="batterywidget.cpp" line="1568"/>
        <source>暂停放电</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.cpp" line="938"/>
        <location filename="batterywidget.cpp" line="1569"/>
        <source>放电完成</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.cpp" line="939"/>
        <location filename="batterywidget.cpp" line="1570"/>
        <source>满电放空</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.cpp" line="940"/>
        <location filename="batterywidget.cpp" line="1571"/>
        <source>半电放空</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.cpp" line="941"/>
        <location filename="batterywidget.cpp" line="1572"/>
        <source>检测中</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.cpp" line="942"/>
        <location filename="batterywidget.cpp" line="1573"/>
        <source>检测完成</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.cpp" line="943"/>
        <location filename="batterywidget.cpp" line="1574"/>
        <source>维护充电</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.cpp" line="944"/>
        <location filename="batterywidget.cpp" line="1575"/>
        <source>维护放电</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.cpp" line="945"/>
        <location filename="batterywidget.cpp" line="1576"/>
        <source>暂停维护</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.cpp" line="946"/>
        <location filename="batterywidget.cpp" line="1577"/>
        <source>维护完成</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.cpp" line="947"/>
        <location filename="batterywidget.cpp" line="1578"/>
        <source>短路</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.cpp" line="948"/>
        <location filename="batterywidget.cpp" line="1579"/>
        <source>过压</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.cpp" line="949"/>
        <location filename="batterywidget.cpp" line="1580"/>
        <source>过流</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.cpp" line="950"/>
        <location filename="batterywidget.cpp" line="1581"/>
        <source>过温</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.cpp" line="951"/>
        <location filename="batterywidget.cpp" line="1582"/>
        <source>风扇异常</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.cpp" line="952"/>
        <location filename="batterywidget.cpp" line="1583"/>
        <source>请接市电</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.cpp" line="953"/>
        <location filename="batterywidget.cpp" line="1584"/>
        <source>电池异常</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.cpp" line="1160"/>
        <location filename="batterywidget.cpp" line="1169"/>
        <source>°C</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.cpp" line="1175"/>
        <location filename="batterywidget.cpp" line="1187"/>
        <source>最大 1200W</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.cpp" line="1177"/>
        <location filename="batterywidget.cpp" line="1189"/>
        <source>停止电流</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.cpp" line="1185"/>
        <source>最大 18.0V</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="batterywidget.ui" line="1894"/>
        <location filename="batterywidget.cpp" line="740"/>
        <location filename="batterywidget.cpp" line="1554"/>
        <source>未连接</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DialogMac</name>
    <message>
        <location filename="dialogmac.ui" line="14"/>
        <source>选择设备</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dialogmac.ui" line="36"/>
        <source>确认</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dialogmac.ui" line="49"/>
        <source>取消</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dialogmac.cpp" line="63"/>
        <source>连接超时</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dialogmac.cpp" line="73"/>
        <source>蓝牙连接中</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>connect485</name>
    <message>
        <location filename="connect485.ui" line="26"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="connect485.ui" line="44"/>
        <source>串 口 号：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="connect485.ui" line="66"/>
        <source>波 特 率：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="connect485.ui" line="88"/>
        <source>级联数量：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="connect485.ui" line="104"/>
        <source>刷新设备</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="connect485.ui" line="111"/>
        <location filename="connect485.cpp" line="147"/>
        <location filename="connect485.cpp" line="188"/>
        <source>打开串口</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="connect485.cpp" line="27"/>
        <location filename="connect485.cpp" line="163"/>
        <source>关闭串口</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="connect485.cpp" line="34"/>
        <source>8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="connect485.cpp" line="46"/>
        <source>4800</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="connect485.cpp" line="47"/>
        <source>9600</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="connect485.cpp" line="48"/>
        <source>115200</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="connect485.cpp" line="151"/>
        <location filename="connect485.cpp" line="158"/>
        <source>提示</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="connect485.cpp" line="152"/>
        <source>请输入级联数量</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="connect485.cpp" line="159"/>
        <source>打开串口失败,请查看串口是否被占用</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
