#include "batterywidget.h"

#include <QApplication>
#include <QTranslator>

QString readSetting();

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    a.setQuitOnLastWindowClosed(true);//最后一个窗口关闭后，程序退出
//    BatteryWidget w;
//    w.setAttribute(Qt::WA_DeleteOnClose);
//    w.setWindowIcon(QIcon(":/image/batteryTopico.ico"));
//    w.show();
//    return a.exec();
    //将QWidget实例创建到堆上
    BatteryWidget *w = new BatteryWidget();
    w->setAttribute(Qt::WA_DeleteOnClose);
    w->setWindowIcon(QIcon(":/image/batteryTopico.ico"));
    w->show();
    return a.exec();
}
